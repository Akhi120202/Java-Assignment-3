//Takes information from super class
public class CombustionEngine extends Engine{

    public CombustionEngine(String type) {
        super(type);
    }
    
}
