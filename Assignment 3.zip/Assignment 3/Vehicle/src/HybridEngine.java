//Takes information from super class
public class HybridEngine extends Engine {
    public HybridEngine(String type) {
        super(type);
    }
    
}
