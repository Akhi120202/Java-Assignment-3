//Takes information from super class
public class ElectricEngine extends Engine{
    public ElectricEngine(String type) {
        super(type);
    }
    
}
